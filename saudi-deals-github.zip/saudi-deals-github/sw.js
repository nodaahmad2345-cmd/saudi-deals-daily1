// ═══════════════════════════════════════════════════════════════
// Saudi Deals Daily — Service Worker (PWA)
// ═══════════════════════════════════════════════════════════════
const CACHE_NAME = 'saudi-deals-v1';
const STATIC_ASSETS = [
  './',
  './saudi-deals-daily-v2.html',
  './sites.json',
  'https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap',
];

// ── تثبيت: تخزين الأصول الأساسية ───────────────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache =>
      cache.addAll(STATIC_ASSETS).catch(() => {})
    )
  );
  self.skipWaiting();
});

// ── تفعيل: حذف الكاشات القديمة ─────────────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// ── جلب: Network-First لـ sites.json، Cache-First للباقي ────────
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // sites.json: دائماً اجلب من الشبكة أولاً
  if (url.pathname.endsWith('sites.json')) {
    event.respondWith(
      fetch(event.request)
        .then(res => {
          const clone = res.clone();
          caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
          return res;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // باقي الأصول: Cache-First
  event.respondWith(
    caches.match(event.request).then(cached =>
      cached || fetch(event.request).then(res => {
        const clone = res.clone();
        caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
        return res;
      })
    )
  );
});

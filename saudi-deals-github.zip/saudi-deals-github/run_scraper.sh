#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# Saudi Deals Daily — Auto-Scraper Runner
# التشغيل التلقائي كل ساعتين عبر cron
# ═══════════════════════════════════════════════════════════════
#
# لإضافة هذا السكريبت إلى cron كل ساعتين:
#   crontab -e
#   أضف السطر التالي:
#   0 */2 * * * /path/to/run_scraper.sh >> /var/log/saudi-deals.log 2>&1
#
# للتحقق من الـ cron jobs الحالية:
#   crontab -l
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

# ── المسارات ──────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/.venv"
SCRAPER="$SCRIPT_DIR/scraper.py"
LOG_FILE="$SCRIPT_DIR/logs/scraper.log"
JSON_FILE="$SCRIPT_DIR/sites.json"
BACKUP_DIR="$SCRIPT_DIR/backups"

# ── ألوان للـ Terminal ────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

log() { echo -e "$(date '+%Y-%m-%d %H:%M:%S') $1"; }

# ── إنشاء المجلدات اللازمة ───────────────────────────────────
mkdir -p "$SCRIPT_DIR/logs" "$BACKUP_DIR"

log "${GREEN}🚀 بدء تحديث عروض السعودية${NC}"

# ── تفعيل البيئة الافتراضية ──────────────────────────────────
if [ -d "$VENV_DIR" ]; then
    source "$VENV_DIR/bin/activate"
    log "✅ تم تفعيل البيئة الافتراضية"
else
    log "${YELLOW}⚠️  لا توجد بيئة افتراضية — الاستخدام مباشر${NC}"
fi

# ── نسخ احتياطي من sites.json الحالي ─────────────────────────
if [ -f "$JSON_FILE" ]; then
    BACKUP="$BACKUP_DIR/sites_$(date '+%Y%m%d_%H%M%S').json"
    cp "$JSON_FILE" "$BACKUP"
    log "💾 نسخة احتياطية: $BACKUP"

    # احتفظ بآخر 24 نسخة فقط (48 ساعة)
    ls -t "$BACKUP_DIR"/sites_*.json 2>/dev/null | tail -n +25 | xargs -r rm --
fi

# ── تشغيل السكريبت ───────────────────────────────────────────
log "⚙️  تشغيل scraper.py ..."
if python3 "$SCRAPER" >> "$LOG_FILE" 2>&1; then
    log "${GREEN}✅ اكتمل الجلب بنجاح${NC}"
else
    EXIT_CODE=$?
    log "${RED}❌ فشل السكريبت بكود: $EXIT_CODE${NC}"
    # استعادة النسخة الاحتياطية
    if [ -f "$BACKUP" ]; then
        cp "$BACKUP" "$JSON_FILE"
        log "${YELLOW}↩️  تم استعادة النسخة الاحتياطية${NC}"
    fi
    exit $EXIT_CODE
fi

# ── إرسال إشعار تليجرام (اختياري) ───────────────────────────
# فعّل هذا القسم بعد إعداد بوت تليجرام
TELEGRAM_ENABLED=false
TELEGRAM_BOT_TOKEN=""
TELEGRAM_CHAT_ID=""

if $TELEGRAM_ENABLED && [ -n "$TELEGRAM_BOT_TOKEN" ] && [ -n "$TELEGRAM_CHAT_ID" ]; then
    TOTAL=$(python3 -c "import json; d=json.load(open('$JSON_FILE')); print(d['total'])")
    TOP=$(python3 -c "
import json
d = json.load(open('$JSON_FILE'))
deals = [s for s in d['sites'] if s.get('discount',0) >= 50]
deals.sort(key=lambda x: x.get('discount',0), reverse=True)
for s in deals[:3]:
    print(f\"  🔥 {s['name']}: {s['discount']}% خصم\")
")
    MSG="🛍️ *تم تحديث عروض السعودية*%0A📊 ${TOTAL} متجر%0A%0A${TOP}"
    curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
        -d "chat_id=${TELEGRAM_CHAT_ID}&text=${MSG}&parse_mode=Markdown" > /dev/null
    log "📱 تم إرسال إشعار تليجرام"
fi

log "${GREEN}✨ انتهى التحديث — $(date '+%H:%M:%S')${NC}"
echo "─────────────────────────────────"

# 🛍️ Saudi Deals Daily

دليل العروض اليومية السعودي — يتحدث تلقائياً كل ساعتين عبر GitHub Actions.

## 🌐 الموقع
**[افتح الموقع هنا](https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/)**

## ⚙️ كيف يعمل؟

```
GitHub Actions (كل ساعتين)
       ↓
  scraper.py يجلب بيانات المتاجر
       ↓
  يحفظ النتائج في sites.json
       ↓
  git push تلقائي
       ↓
  index.html يقرأ sites.json عبر fetch()
```

## 📁 هيكل المشروع

| الملف | الوظيفة |
|---|---|
| `scraper.py` | سكريبت الجلب (Python + Playwright) |
| `sites.json` | بيانات المتاجر المحدّثة (مولّد تلقائياً) |
| `index.html` | الواجهة الأمامية (GitHub Pages) |
| `.github/workflows/scrape.yml` | جدولة GitHub Actions |

## 🚀 التشغيل المحلي

```bash
pip install -r requirements.txt
playwright install chromium
python scraper.py
```
